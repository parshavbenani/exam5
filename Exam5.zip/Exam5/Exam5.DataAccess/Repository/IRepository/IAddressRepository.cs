﻿using Exam5.DataAccess.Data;
using Exam5.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exam5.DataAccess.Repository.IRepository
{
    public interface IAddressRepository
    {
        public IEnumerable<Address> GetAddress();
        Task<Address> AddAddress(Address address);
    
    }
}
