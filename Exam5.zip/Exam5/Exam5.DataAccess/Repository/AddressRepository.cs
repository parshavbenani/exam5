﻿using Exam5.DataAccess.Data;
using Exam5.DataAccess.Repository.IRepository;
using Exam5.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exam5.DataAccess.Repository
{
    public class AddressRepository : IAddressRepository
    {
        private readonly ApplicationDbContext _dbContext;

        public AddressRepository(ApplicationDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<Address> AddAddress(Address address)
        {
            _dbContext.Add(address);
            _dbContext.SaveChanges();
            return address;
        }

        public IEnumerable<Address> GetAddress()
        {
            return _dbContext.address.ToList();
        }

    }
}
