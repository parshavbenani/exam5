using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Exam5.DataAccess.Data;
using System.Linq;
using Exam5.DataAccess.Repository;
using Exam5.DataAccess.Repository.IRepository;
using Exam5.Models;
using Exam4API.Models;

namespace Exam5
{
    public class Function1
    {
        private readonly IAddressRepository _addressRepository;
        private readonly IOrderRepository _orderRepository;
       
        public Function1(IAddressRepository addressRepository,IOrderRepository orderRepository)
        {
            _addressRepository= addressRepository;
            _orderRepository= orderRepository;
        }
      

        [FunctionName("GetAddressList")]
        public async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Anonymous, "get", "post", Route = null)] HttpRequest req,
            ILogger log)
        {
            var address1 = _addressRepository.GetAddress();
            return new OkObjectResult(address1);
        }

        [FunctionName("AddAddress")]
        public async Task<IActionResult> Run1(
            [HttpTrigger(AuthorizationLevel.Anonymous, "get", "post", Route = null)] HttpRequest req,
            ILogger log)
        {
            try
            {
                string requestbody = await new StreamReader(req.Body).ReadToEndAsync();
                var add = JsonConvert.DeserializeObject<Address>(requestbody);
                var Addadd = _addressRepository.AddAddress(add);
                return new OkObjectResult(new Response { Data = Addadd,Status = "Success"});
            }
            catch(Exception ex)
            {
                log.LogError(ex, "Error");
                return new StatusCodeResult(500);
            }
          
        }

        [FunctionName("UpdateOrderStatus")]
        public async Task<IActionResult> Run2(
           [HttpTrigger(AuthorizationLevel.Anonymous, "get", "post", Route = null)] HttpRequest req,
           ILogger log)
        {
            var orderid = req.Query["Oid"];
            var status = req.Query["status"];
            var Order = _orderRepository.GetFirstOrDefault(x => x.OrderId == int.Parse(orderid));
            if(Order.IsActive!= false)
            {              
                _orderRepository.Update(Order);               
            }
            return new OkObjectResult(new Response { Data = Order,Status = "Success"});

        }

     }
}
