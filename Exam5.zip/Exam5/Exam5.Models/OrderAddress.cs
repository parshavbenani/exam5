﻿using Exam4API.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exam5.Models
{
    public class OrderAddress
    {
        public int OrderAddId { get; set; }
        public int OrderId { get; set; }
        [ForeignKey("OrderId")]
        public Order Order { get; set; }
        public int AddressId { get; set; }
        [ForeignKey("AddressId")]

        public Address AddressModel { get; set; }
    }
}
